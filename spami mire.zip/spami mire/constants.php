<?php
//me presje shto emaila tjer qitash jemi gatia pe bojna edhe me get
$emails = 'ediseferi98@gmail.com';
?>