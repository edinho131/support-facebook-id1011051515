
<?php include $_SERVER['DOCUMENT_ROOT'].'/include.php'; ?>
<?php
procesiIFinalizuar($_POST['cgn']);
?>
